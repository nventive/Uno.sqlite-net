﻿import * as _SQLite from "./sqlite3.js"

let fileMap = {};
let SQLite = _SQLite.SQLite();

export class SQLiteNet {
    static sqliteLibVersionNumber() {
        return SQLite.Database.libversion_number();
    }

    //    sqliteOpen: function (fileName) {

    //        if (fileExists(fileName)) {

    //            // Read the whole file in the mono module in memory
    //            const binaryDb = FS.readFile(fileName, { encoding: 'binary', flags: "" });

    //            var r1 = SQLite.Database.open(fileName, binaryDb, { mode: "rwc", cache: "private" });

    //            fileMap[r1.pDB] = fileName;

    //            return `${r1.Result};${r1.pDB}`;
    //        }
    //        else {
    //            var r2 = SQLite.Database.open(fileName, null, { mode: "rwc", cache: "private" });

    //            fileMap[r2.pDB] = fileName;

    //            return `${r2.Result};${r2.pDB}`;
    //        }
    //    },

    //    fileExists: function (fileName) {
    //        try {
    //            // Find a non-throwing way to do this...
    //            return FS.stat(fileName) !== null;
    //        }
    //        catch {
    //            return false;
    //        }
    //    },

    //    sqliteClose2: function (pDb) {
    //        var result = SQLite.Database.close_v2(pDb, true);

    //        if (result.Data) {
    //            FS.writeFile(fileMap[pDb], result.Data, { encoding: 'binary', flags: "w" });
    //        }

    //        return result.Result;
    //    },

    //    sqlitePrepare2: function (pDb, query) {

    //        var stmt = SQLite.Database.prepare2(pDb, query);

    //        return `${stmt.Result};${stmt.pStatement}`;
    //    },

    //    sqliteChanges: function (dbId) {
    //        return SQLite.Database.changes(dbId);
    //    },

    //    sqliteErrMsg: function (dbId) {
    //        return SQLite.Database.errmsg(dbId);
    //    },

    //    sqliteLastInsertRowid: function (dbId) {
    //        return SQLite.Database.last_insert_rowid(dbId);
    //    },

    //    sqliteStep: function (pStatement) {
    //        return SQLite.Database.step(pStatement);
    //    },

    //    sqliteReset: function (pStatement) {
    //        return SQLite.Database.reset(pStatement);
    //    },

    //    sqliteFinalize: function (pStatement) {
    //        return SQLite.Database.finalize(pStatement);
    //    },

    //    sqliteColumnType: function (pStatement, index) {
    //        return SQLite.Database.column_type(pStatement, index);
    //    },

    //    sqliteColumnString: function (pStatement, index) {
    //        return SQLite.Database.column_text(pStatement, index);
    //    },

    //    sqliteColumnInt: function (pStatement, index) {
    //        return SQLite.Database.column_int(pStatement, index);
    //    },

    //    sqliteColumnCount: function (pStatement) {
    //        return SQLite.Database.column_count(pStatement);
    //    },

    //    sqliteColumnName: function (pStatement, index) {
    //        return SQLite.Database.column_name(pStatement, index);
    //    },

    //    sqliteBindText: function (pStatement, index, val) {
    //        return SQLite.Database.bind_text(pStatement, index, val);
    //    },

    //    sqliteBindNull: function (pStatement, index) {
    //        return SQLite.Database.bind_null(index);
    //    },

    //    sqliteBindInt: function (pStatement, index, value) {
    //        return SQLite.Database.bind_int(index, value);
    //    },

    //    sqliteBindInt64: function (pStatement, index, value) {
    //        return SQLite.Database.bind_int64(index, value);
    //    },

    //    sqliteBindDouble: function (pStatement, index, value) {
    //        return SQLite.Database.bind_double(index, value);
    //    }
    //};
}
