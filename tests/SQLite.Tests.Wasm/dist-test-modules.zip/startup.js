﻿import * as SQLiteNet from './sqlite.js';
import * as UnoBootstrap from './uno-bootstrap.js';
import * as Mono from './mono.js';

window.SQLiteNet = SQLiteNet.SQLiteNet;

// var r = _SQLiteNet.sqliteLibVersionNumber();

var assemblies = ["mscorlib.clr", "netstandard.clr", "SQLite.Tests.Wasm.clr", "SQLite-net-wasm.clr", "System.clr", "System.Core.clr"];
document.addEventListener(
    "DOMContentLoaded",
    function (event) {

        // eval('window.SQLiteNet.sqliteLibVersionNumber()');
        // Mono.toString();

        UnoBootstrap.unoWasmMain(
            "SQLite.Tests.Wasm",
            "SQLiteTests",
            "Program",
            "Main",
            assemblies,
            "managed-022fc1ad4671c0cee693a2475994a95ad3d31196",
            "clr",
            false
        );
    }
);
